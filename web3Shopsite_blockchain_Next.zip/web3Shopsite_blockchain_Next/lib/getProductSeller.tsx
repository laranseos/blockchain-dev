const getProductSeller = (data) => {
  const businessName = data?.business?.businessName

  return businessName
}

export default getProductSeller

import SeoHead from "./SeoHead"

export default SeoHead

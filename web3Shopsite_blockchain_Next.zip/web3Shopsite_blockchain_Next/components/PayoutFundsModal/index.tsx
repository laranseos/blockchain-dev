import PayoutFundsModal from "./PayoutFundsModal"

export default PayoutFundsModal

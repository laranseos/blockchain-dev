import CheckOutModal from "./CheckOutModal"

export default CheckOutModal

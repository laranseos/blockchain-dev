import PendingApprovalModal from "./PendingApprovalModal"

export default PendingApprovalModal

import GradientText from "./GradientText"

export default GradientText

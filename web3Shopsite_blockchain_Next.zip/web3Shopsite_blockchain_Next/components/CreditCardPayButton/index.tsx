import CreditCardPayButton from "./CreditCardPayButton"

export default CreditCardPayButton

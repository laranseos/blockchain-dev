import DashboardPage from "./DashboardPage"

export default DashboardPage

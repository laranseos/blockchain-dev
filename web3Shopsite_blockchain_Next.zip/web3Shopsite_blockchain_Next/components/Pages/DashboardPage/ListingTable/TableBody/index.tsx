import TableBody from "./TableBody"

export default TableBody

import ListingsTable from "./ListingsTable"

export default ListingsTable

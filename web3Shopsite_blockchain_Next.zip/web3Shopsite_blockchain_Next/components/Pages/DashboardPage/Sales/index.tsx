import Sales from "./Sales"

export default Sales

import TransactionTable from "./TransactionTable"

export default TransactionTable

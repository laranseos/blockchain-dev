import TableFooter from "./TableFooter"

export default TableFooter

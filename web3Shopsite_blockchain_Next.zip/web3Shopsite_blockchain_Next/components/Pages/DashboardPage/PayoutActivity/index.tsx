import PayoutActivity from "./PayoutActivity"

export default PayoutActivity

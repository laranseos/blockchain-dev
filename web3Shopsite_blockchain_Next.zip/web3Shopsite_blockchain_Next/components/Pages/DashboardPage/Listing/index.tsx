import Listing from "./Listing"

export default Listing

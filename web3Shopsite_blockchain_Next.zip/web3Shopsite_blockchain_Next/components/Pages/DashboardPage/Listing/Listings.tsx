import ListingsTable from "../ListingTable"

const Listings = () => <ListingsTable />

export default Listings

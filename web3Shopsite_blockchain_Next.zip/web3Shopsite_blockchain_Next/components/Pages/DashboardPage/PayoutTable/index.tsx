import PayoutTable from "./PayoutTable"

export default PayoutTable

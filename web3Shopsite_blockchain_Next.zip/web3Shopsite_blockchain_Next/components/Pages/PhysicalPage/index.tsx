import PhysicalPage from "./PhysicalPage"

export default PhysicalPage

import AccountPage from "./AccountPage"

export default AccountPage

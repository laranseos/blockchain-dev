export const demoProduct = [
  {
    title: "SHIRT",
    image:
      "https://nftstorage.link/ipfs/bafybeihmnfnijkvf66cpeprv2uea5734keszdjwlsjulkiifu4o4oq2ds4",
    price: "777000000000000",
    sellerName: "sweetman",
    contractAddress: "0xf4bd2d6adb77de6977896c6069f6cfd72adcc1b2",
    description:
      "Description of item lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod consectetur mi, id fermentum turpis sollicitudin sed. Nulla facilisi. Fusce non bibendum nulla. Maecenas vehicula.",
  },
]

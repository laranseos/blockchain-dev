import CheckOutSuccessPage from "./CheckOutSuccessPage"

export default CheckOutSuccessPage

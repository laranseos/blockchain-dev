import CoverPage from "./CoverPage"

export default CoverPage

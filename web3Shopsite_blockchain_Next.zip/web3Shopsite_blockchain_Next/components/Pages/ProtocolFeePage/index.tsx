import ProtocolFeePage from "./ProtocolFeePage"

export default ProtocolFeePage

import TrendingList from "./TrendingList"

export default TrendingList

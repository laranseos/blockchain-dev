import Trending from "./Trending"

export default Trending

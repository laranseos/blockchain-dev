import Newest from "./Newest"

export default Newest

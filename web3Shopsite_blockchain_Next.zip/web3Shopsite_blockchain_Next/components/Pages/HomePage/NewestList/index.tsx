import NewestList from "./NewestList"

export default NewestList

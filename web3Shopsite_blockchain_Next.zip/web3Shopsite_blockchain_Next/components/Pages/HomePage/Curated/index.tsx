import Curated from "./Curated"

export default Curated

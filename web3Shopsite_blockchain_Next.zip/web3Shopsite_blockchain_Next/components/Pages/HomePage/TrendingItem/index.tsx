import TrendingItem from "./TrendingItem"

export default TrendingItem

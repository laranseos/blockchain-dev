import CreatePage from "./CreatePage"

export default CreatePage

import DigitalPage from "./DigitalPage"

export default DigitalPage

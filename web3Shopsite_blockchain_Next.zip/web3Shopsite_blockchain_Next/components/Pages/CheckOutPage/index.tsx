import CheckOutPage from "./CheckOutPage"

export default CheckOutPage

import ConstructionPage from "./ConstructionPage"

export default ConstructionPage

import CreateAccountButton from "./CreateAccountButton"

export default CreateAccountButton

import EditAccountButton from "./EditAccountButton"

export default EditAccountButton

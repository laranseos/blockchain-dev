import SellerName from "./SellerName"

export default SellerName

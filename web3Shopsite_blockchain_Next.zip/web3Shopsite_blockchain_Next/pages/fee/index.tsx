import ProtocolFeePage from "@/components/Pages/ProtocolFeePage"

const Page = () => <ProtocolFeePage />

export default Page

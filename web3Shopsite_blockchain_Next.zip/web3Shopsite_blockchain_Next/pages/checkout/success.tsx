import CheckOutSuccessPage from "../../components/Pages/CheckOutSuccessPage"

const CheckOutSuccess = () => <CheckOutSuccessPage />

export default CheckOutSuccess
